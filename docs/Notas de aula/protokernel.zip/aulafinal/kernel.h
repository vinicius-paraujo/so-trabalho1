#ifndef KERNEL_H
#define KERNEL_H

extern void (*OutChar)(char, unsigned int);

#endif
