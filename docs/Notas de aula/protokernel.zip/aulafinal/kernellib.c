#include "kernel.h"

void (*OutChar)(char, unsigned int)
    __attribute__((section(".imports")));
