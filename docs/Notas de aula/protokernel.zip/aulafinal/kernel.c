#include <Uefi.h>

#include <Library/UefiBootServicesTableLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/BaseLib.h>
#include <Protocol/SimpleFileSystem.h>
#include <Guid/FileInfo.h>
#include <Library/SynchronizationLib.h>

#include <Protocol/GraphicsOutput.h>

EFI_MEMORY_DESCRIPTOR *Map = NULL;
UINT32 *Framebuffer;
UINT32 Width;
UINT32 Height;
UINT32 PixelsPerScanLine;

//PILHAS ==============================
#define STACK_SIZE 8192
//=====================================


//Processos ===========================
typedef struct
{

  UINT8 *Stack;
  UINT64 Rsp;
  UINT64 Cr3;
  VOID *base;
  UINT64 entry;
  CHAR8 arg;

} PROCESS;

PROCESS Process[2];

volatile UINTN CurrentProcess = 0;
volatile UINT8 ProcessStarted = 0;

volatile UINT32 Lock = 0;

VOID Acquire()
{
   while(InterlockedCompareExchange32( &Lock, 0, 1 ) != 0);
}

VOID Release()
{
    Lock = 0;
}
//=====================================

//Gerenciamento mínimo de memória =====
#define KERNEL_HEAP_SIZE (1024*1024)
VOID *KernelHeap;
UINTN HeapOffset = 0;

VOID* kalloc(UINTN Size)
{

     VOID *addr = (UINT8*)KernelHeap + HeapOffset;

     HeapOffset = (HeapOffset + Size + 15) & ~15;

     return addr;

}

//=====================================

UINTN X = 0;
UINTN Y = 0;
UINTN Toggle = 0;
static UINT8 charX[8] = { 
0b10000001,
0b01000010,
0b00100100,
0b00011000,
0b00011000,
0b00100100,
0b01000010,
0b10000001
};

static UINT8 charO[8] = { 
0b00111100,
0b01000010,
0b10000001,
0b10010001,
0b10010001,
0b10000001,
0b01000010,
0b00111100
};

VOID SetPixel( UINTN X, UINTN Y, UINT32 Color)
{
  Framebuffer[Y*PixelsPerScanLine + X] = Color;
}

VOID DrawChar( UINTN Px, UINTN Py, UINT8* ch, UINT32 Color)
{
  for(UINTN y = 0; y < 8; y++)
  {
    UINT8 Row = ch[y];
    for(UINTN x = 0; x < 8; x++)
    {
      if(Row & (1 << (7-x)))
        SetPixel(Px + x, Py + y, Color);    
    }
  }
}

VOID CursorStep()
{
      X += 8;
      if(X + 8 >= Width)
      {
         X = 0;
         Y += 8;
      }
      if(Y + 8 >= Height)
         Y = 0;
}

VOID OutChar(CHAR8 ch, UINT32 color)
{
    Acquire();
    if(ch == 'O')
        DrawChar(X, Y, charO, color);
    else
        DrawChar(X, Y, charX, color);
    CursorStep();
    Release();
}

//Loader ==================================
VOID *LoadFile(CHAR16 *FileName)
{
    EFI_STATUS Status;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *Fs;
    EFI_FILE_PROTOCOL *Root;
    EFI_FILE_PROTOCOL *File;
    
    Status = gBS->LocateProtocol(&gEfiSimpleFileSystemProtocolGuid, NULL, (VOID**)&Fs);
    if(EFI_ERROR(Status)) return NULL;
    
    Status = Fs->OpenVolume(Fs, &Root);
    if(EFI_ERROR(Status)) return NULL;
    
    Status = Root->Open(Root, &File, FileName, EFI_FILE_MODE_READ, 0);
    if(EFI_ERROR(Status)) 
    {
      Root->Close(Root);
      return NULL;
    }
    
    VOID *Image = kalloc(64*1024);
    VOID *Ptr = (UINT8*)Image;
    
    while(1)
    {
      UINTN Size = 4096;
      Status = File->Read(File, &Size, Ptr);
      
      if(EFI_ERROR(Status)) break;
      
      if(Size == 0) break;
      
      Ptr += Size;
    }
    File->Close(File);
    Root->Close(Root);
    
    return Image;
}

UINT64 LoadProcess(UINTN Id, CHAR16 *File, CHAR8 Arg)
{
  Process[Id].base = LoadFile(File);
  Process[Id].arg = Arg;
  
  *(UINT64*)Process[Id].base = (UINT64)OutChar;
  
  return (UINT64)Process[Id].base + sizeof(UINT64);
}
//=========================================

VOID ExitBoot(EFI_HANDLE ImageHandle)
{
  UINTN MapSize = 0;
  UINTN MapKey;
  UINTN DescSize;
  UINT32 DescVersion;
  
  gBS->GetMemoryMap( &MapSize, Map, &MapKey, &DescSize, &DescVersion );
  MapSize += DescSize * 8;
  gBS->AllocatePool( EfiLoaderData, MapSize, (VOID**)&Map );
  
  while(1)
  {
    gBS->GetMemoryMap( &MapSize, Map, &MapKey, &DescSize, &DescVersion );
    EFI_STATUS status = gBS->ExitBootServices( ImageHandle, MapKey );
    if (!EFI_ERROR(status)) break;
  }
}

//Configuração da interrupção do timer ====================================================
typedef struct {

  UINT16 OffsetLow;
  UINT16 Selector;
  
  UINT8 Ist;
  UINT8 TypeAttr;
  
  UINT16 OffsetMid;
  UINT32 OffsetHigh;
  
  UINT32 Zero;

} __attribute__((packed)) IDT_ENTRY;

IDT_ENTRY Idt[256];

#define TIMER_VECTOR 32

VOID SendEOI()
{
  AsmWriteMsr64(0x80B, 0);
}

VOID EnableX2Apic()
{
   UINT64 ApicBase = AsmReadMsr64(0x1B);
   
   ApicBase |= (1ULL << 11); //Habilite APIC
   ApicBase |= (1ULL << 10); //Habilite x2APIC
   
   AsmWriteMsr64(0x1B, ApicBase);
}

VOID SetupApicTimer()
{
   AsmWriteMsr64(0x83E, 3); //Divisor do timer = 16
   
   AsmWriteMsr64(0x832, TIMER_VECTOR | (1 << 17)); //Interrupção 32 da IDT e Timer Periódico
   
   AsmWriteMsr64(0x838, 500000); //Contador do timer: interrupção dispara a cada 500000 passos
}

VOID SetIdtGate(INTN Vector, VOID* Handler)
{
    UINT64 Addr = (UINT64)Handler;
    
    Idt[Vector].OffsetLow = Addr & 0xFFFF;
    
    UINT16   cs;
    
    __asm__ volatile(
      "mov %%cs, %0"
      : "=r"(cs)
    );
    
    Idt[Vector].Selector = cs;
    Idt[Vector].Ist = 0;
    Idt[Vector].TypeAttr = 0b10001110;
    Idt[Vector].OffsetMid = (Addr >> 16) & 0xFFFF;
    Idt[Vector].OffsetHigh = (Addr >> 32);
    Idt[Vector].Zero = 0;
}

//=========================================================================================
VOID LoadIdt()
{
  IA32_DESCRIPTOR Idtr;
  
  Idtr.Base = (UINT64)Idt;
  Idtr.Limit = sizeof(Idt) - 1;
  
  AsmWriteIdtr(&Idtr);
}

UINTN quantum = 0;
__attribute__((used))
UINT64 Scheduler(UINT64 CurrentRsp)
{
      quantum++;
      
      if(!ProcessStarted) return CurrentRsp;
      
      Process[CurrentProcess].Rsp = CurrentRsp;
      
      if(CurrentProcess == 0)
      {
         if(quantum >= 1)
         {
             quantum = 0;
             CurrentProcess = 1;
         }
      }
      else
      {
         CurrentProcess = 0;
      }
      
      //Nova linha (Troca de CR3, isto é, do registrador do endereço da tabela de paginação - espaço de endereçamento)
      AsmWriteCr3(Process[CurrentProcess].Cr3);
      
      SendEOI();
      
      return Process[CurrentProcess].Rsp;

}

__attribute__((naked))
VOID timer_stub()
{
  __asm__ volatile(
    ".intel_syntax noprefix\n"
    "push rax\n"
    "push rbx\n"
    "push rcx\n"
    "push rdx\n"
    "push rsi\n"
    "push rdi\n"
    "push rbp\n"
    "push r8\n"
    "push r9\n"
    "push r10\n"
    "push r11\n"
    "push r12\n"
    "push r13\n"
    "push r14\n"
    "push r15\n"
    
    "mov rdi, rsp\n"
    
    "call Scheduler\n"
    
    "mov rsp, rax\n"
    
    "pop r15\n"
    "pop r14\n"
    "pop r13\n"
    "pop r12\n"
    "pop r11\n"
    "pop r10\n"
    "pop r9\n"
    "pop r8\n"
    "pop rbp\n"
    "pop rdi\n"
    "pop rsi\n"
    "pop rdx\n"
    "pop rcx\n"
    "pop rbx\n"
    "pop rax\n"
    
    "iretq\n"
    ".att_syntax prefix\n"
  );
}

VOID InitProcess(UINTN Id, UINT64 (*Entry)())
{
    UINT8 *StackBase = kalloc(STACK_SIZE);
    UINT64 cr3 = AsmReadCr3();

    UINT64 *rsp = (UINT64*)(StackBase + STACK_SIZE);
    rsp = (UINT64*)((UINT64)rsp & ~15);
    
    UINT16 cs, ss;
    __asm__ volatile("mov %%cs, %0" : "=r"(cs));
    __asm__ volatile("mov %%ss, %0" : "=r"(ss));
    
    *(--rsp) = ss;
    *(--rsp) = (UINT64)(StackBase + STACK_SIZE);
    *(--rsp) = 0x202;
    *(--rsp) = cs;
    *(--rsp) = (UINT64)Entry;

    *(--rsp) = 0;              // rax
    *(--rsp) = 0;              // rbx
    *(--rsp) = 0;              // rcx
    *(--rsp) = 0;              // rdx
    *(--rsp) = 0;              // rsi
    *(--rsp) = (UINT64)Process[Id].arg; // rdi (1º argumento)

    *(--rsp) = 0;              // rbp
    *(--rsp) = 0;              // r8
    *(--rsp) = 0;              // r9
    *(--rsp) = 0;              // r10
    *(--rsp) = 0;              // r11
    *(--rsp) = 0;              // r12
    *(--rsp) = 0;              // r13
    *(--rsp) = 0;              // r14
    *(--rsp) = 0;              // r15


    Process[Id].Rsp = (UINT64)rsp;
    Process[Id].Stack = StackBase;
    Process[Id].Cr3 = cr3;
    Process[Id].entry = (UINT64)Entry;
    
    
}


EFI_STATUS EFIAPI UefiMain(IN EFI_HANDLE ImageHandle, 
                           IN EFI_SYSTEM_TABLE *SystemTable)
{
   EFI_GRAPHICS_OUTPUT_PROTOCOL *Gop;
   gBS->LocateProtocol( &gEfiGraphicsOutputProtocolGuid, NULL, (VOID**)&Gop);
   
   Framebuffer = (UINT32*) Gop->Mode->FrameBufferBase;
   Width = Gop->Mode->Info->HorizontalResolution;
   Height = Gop->Mode->Info->VerticalResolution;
   PixelsPerScanLine = Gop->Mode->Info->PixelsPerScanLine;
   
   gBS->AllocatePool(EfiLoaderData, KERNEL_HEAP_SIZE, &KernelHeap);
   
   UINT64 entry1 = LoadProcess(0, L"\\draw.app", 'O');
   UINT64 entry2 = LoadProcess(1, L"\\draw.app", 'X');
   
   ExitBoot(ImageHandle);
   
   ZeroMem(Idt, sizeof(Idt));
   SetIdtGate(32, timer_stub);
   LoadIdt();
   
   EnableX2Apic();
   SetupApicTimer();
   
   InitProcess(0, (UINT64(*)())entry1);
   InitProcess(1, (UINT64(*)())entry2);
   
   CurrentProcess = 0;
   ProcessStarted = 1;
   
   __asm__ volatile(
        ".intel_syntax noprefix\n"
        
        "mov rsp, %0\n"
        
        "pop r15\n" "pop r14\n" "pop r13\n" "pop r12\n"
        "pop r11\n" "pop r10\n" "pop r9\n"  "pop r8\n"
        "pop rbp\n" "pop rdi\n" "pop rsi\n" "pop rdx\n"
        "pop rcx\n" "pop rbx\n" "pop rax\n"
        
        "iretq\n"
        
        ".att_syntax prefix\n"
        :: "r" (Process[0].Rsp)
   );

   return EFI_SUCCESS;

}
