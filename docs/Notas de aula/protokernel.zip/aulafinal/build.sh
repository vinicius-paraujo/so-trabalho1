#!/bin/bash

build -a X64 -t GCC -p MdeModulePkg/MdeModulePkg.dsc -m MdeModulePkg/Application/aulafinal/aulafinal.inf
