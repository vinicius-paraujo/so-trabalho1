#include "kernel.h"

void Main(char Symbol)
{
    unsigned int Color;

    switch(Symbol)
    {
        case 'X':
            Color = 0x00FFFF00;
            break;

        case 'O':
            Color = 0x0000FF00;
            break;

        default:
            Color = 0x00FFFFFF;
            break;
    }

    while(1)
    {
        OutChar(Symbol, Color);

        for(volatile unsigned long long t = 0; t < 300000; t++);
    }
}
