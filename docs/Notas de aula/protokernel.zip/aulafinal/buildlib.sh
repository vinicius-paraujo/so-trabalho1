#!/bin/bash
set -e

echo "[1/2] Compilando kernellib.c..."

gcc \
    -ffreestanding \
    -fno-pic \
    -fno-stack-protector \
    -mno-red-zone \
    -c kernellib.c \
    -o kernellib.slb

echo "[2/2] OK -> kernellib.slb gerado"
