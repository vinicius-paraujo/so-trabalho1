#!/bin/bash
set -e

DISK="disco.img"
MNT=./mnt

mkdir -p "$MNT"

cp ../../../Build/MdeModule/DEBUG_GCC/X64/aulafinal.efi ./BOOTX64.EFI

# cria imagem de 64 MiB usando dd
dd if=/dev/zero of="$DISK" bs=1M count=64 status=progress

# GPT + ESP
parted -s "$DISK" mklabel gpt
parted -s "$DISK" mkpart ESP fat32 1MiB 100%
parted -s "$DISK" set 1 esp on

# associa loop device
LOOP=$(sudo losetup --show -fP "$DISK")

# formata partição EFI em FAT32
sudo mkfs.fat -F32 "${LOOP}p1"

# monta e copia o EFI
sudo mount "${LOOP}p1" "$MNT"

sudo mkdir -p "$MNT/EFI/BOOT"
sudo cp BOOTX64.EFI "$MNT/EFI/BOOT/BOOTX64.EFI"
sudo cp draw.bin "$MNT/draw.bin"

sync

# desmonta e limpa
sudo umount "$MNT"
sudo losetup -d "$LOOP"

sudo rmdir "$MNT"

cp /usr/share/OVMF/OVMF_VARS_4M.ms.fd ./OVMF_VARS_4M.fd
sudo qemu-system-x86_64 \
  -machine q35 \
  -enable-kvm \
  -cpu host,+x2apic \
  -device qemu-xhci \
  -drive if=pflash,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd \
  -drive if=pflash,format=raw,file=OVMF_VARS_4M.fd \
  -drive file=disco.img,format=raw,if=none,id=usbdisk \
  -device usb-storage,drive=usbdisk


