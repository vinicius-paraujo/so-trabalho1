#!/bin/bash
set -e

echo "[1/4] Compilando draw.c..."

gcc \
    -ffreestanding \
    -fno-pic \
    -fno-stack-protector \
    -mno-red-zone \
    -c draw.c \
    -o draw.o

echo "[2/4] Linkando draw.o + kernellib.slb..."

ld \
    -T draw.ld \
    -nostdlib \
    draw.o \
    kernellib.slb \
    -o draw.elf

echo "[3/4] Convertendo ELF → BIN flat..."

objcopy \
    -O binary \
    draw.elf \
    draw.app

echo "[4/4] OK -> draw.app gerado"
