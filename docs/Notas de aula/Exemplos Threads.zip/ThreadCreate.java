/*
 * Criação de threads em Java.
 *
 * Equivalente ao programa thread-create.c
 */

public class ThreadCreate {

    static final int NUM_THREADS = 16;

    static class ThreadBody extends Thread {

        private final int tid;

        public ThreadBody(int tid) {
            this.tid = tid;
        }

        @Override
        public void run() {

            System.out.printf("t%02d: Olá!%n", tid);

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Thread interrompida: " + tid);
                return;
            }

            System.out.printf("t%02d: Tchau!%n", tid);
        }
    }

    public static void main(String[] args) {

        Thread[] threads = new Thread[NUM_THREADS];

        for (int i = 0; i < NUM_THREADS; i++) {

            System.out.printf("Main: criando thread %02d%n", i);

            threads[i] = new ThreadBody(i);
            threads[i].start();
        }

        System.out.println("Main: fim");
    }
}