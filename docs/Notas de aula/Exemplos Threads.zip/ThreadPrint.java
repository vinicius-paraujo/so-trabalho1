/*
 * Criação de threads em Java, com impressão de variáveis.
 *
 * Equivalente ao programa thread-print.c
 */

public class ThreadPrint {

    static final int NUM_THREADS = 16;

    // Variável global compartilhada entre as threads
    static int x = 0;

    static class ThreadBody extends Thread {

        private final int tid;

        public ThreadBody(int tid) {
            this.tid = tid;
        }

        private synchronized void doIt(){
            x++;
            System.out.printf("t%02d: Olá!   (x=%02d)%n", tid, x);

            // Thread.sleep(3000); // equivalente ao sleep(3) do C

            x++;
            System.out.printf("t%02d: Tchau! (x=%02d)%n", tid, x);           
        }

        @Override
        public void run() {
            doIt();
        }
    }

    public static void main(String[] args) {

        Thread[] threads = new Thread[NUM_THREADS];

        for (int i = 0; i < NUM_THREADS; i++) {

            System.out.printf("Main: criando thread %02d%n", i);

            threads[i] = new ThreadBody(i);
            threads[i].start();
        }

        System.out.println("Main: fim");
    }
}