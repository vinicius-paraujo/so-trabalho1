#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {

  printf("Processo inicial: PID = %d\n", getpid());

  for (int i = 0; i < 4; i++) {

    fork();

    printf(
      "Iteracao %d | PID = %d | PPID = %d\n",
      i,
      getpid(),
      getppid()
    );
  }

  return 0;
}